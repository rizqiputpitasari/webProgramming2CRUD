-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2019 at 06:05 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 5.6.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabledata`
--

CREATE TABLE `tabledata` (
  `Id` int(10) NOT NULL,
  `Nama` varchar(30) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabledata`
--

INSERT INTO `tabledata` (`Id`, `Nama`, `Username`, `Password`, `Email`) VALUES
(2, 'rizqi putpitasari', 'rizqi', 'qwertyuioop', 'rizqi@gmail.com'),
(3, 'rio sakti sumarsono', 'rio', 'riosakti', 'rio@gmail.com'),
(4, 'Edgar adit pradana', 'edgar', 'edgar1234', 'edgar123@gmail.com'),
(6, 'Ardan Ghofur Dwi Aryana', 'Ardan', 'ardangovur', 'Ardan@gmail.com'),
(7, 'Davina Pamungkas', 'Davina', 'davina1234', 'davina@gmail.com'),
(9, 'putri saudiyah', 'putri', 'putri12345', 'putri@gmail.com'),
(10, 'ricy lufie wandini', 'ricy', 'ricyllufie', 'ricy@gmail.com'),
(11, 'puput reyka kurniawan', 'puput', 'puput20april', 'puput@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tabledata`
--
ALTER TABLE `tabledata`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tabledata`
--
ALTER TABLE `tabledata`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
